SELECT *
FROM Proprietario
WHERE Nome LIKE '%' || ? || '%'

